<?php
$config["server"]='localhost';
$config["username"]='root';
$config["password"]='';
$config["database_name"]='sp_cf';